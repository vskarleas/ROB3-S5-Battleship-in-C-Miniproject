// #############################################################################
// # File load.h
// # UE Infomatics for Robotics - Polytech Sorbonne - 2023/2024 - S5
// # Authors: Yannis Sadoun, Vasileios Filippos Skarleas - All rights reserved.
// #############################################################################

#ifndef _LOAD_H_
#define _LOAD_H_

int load(int language);

#endif